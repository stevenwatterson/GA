## -*- texinfo -*-
## @deftypefn{Function File} {@var{parents} =} selectionstochunuf (@var{expections}, @var{nParents}, @var{options})
## Default selection function
##
## Selection based uniform proportional steps based on its caled value.
##
## @strong{Inputs}
## @table @var
## @item expectation
## Column vector of scaled fitness for each member of a population.
## @item nParents
## The number of parents to select
## @item options
## ga options
## @end table
##
## @strong{Outputs}
## @table @var
## @item parents
## Row vector of size nParents containg the indices of selected parents.
## @end table
## 
## @seealso{ga}
## @end deftypefn
function parents = selectionstochunif (expectation, nParents, options)
  nc_expectation = columns (expectation);
  line(1, 1:nc_expectation) = cumsum (expectation(1, 1:nc_expectation));
  max_step_size = line(1, nc_expectation);
  step_size = max_step_size * rand ();
  steps(1, 1:nParents) = rem (step_size * (1:nParents), max_step_size);
  for index_steps = 1:nParents ## fix an entry of the steps (or parents) vector
    #assert (steps(1, index_steps) < max_step_size); ## DEBUG
    index_line = 1;
    while (steps(1, index_steps) >= line(1, index_line))
      #assert ((index_line >= 1) && (index_line < nc_expectation)); ## DEBUG
      index_line++;
    endwhile
    parents(1, index_steps) = index_line;
  endfor
endfunction
