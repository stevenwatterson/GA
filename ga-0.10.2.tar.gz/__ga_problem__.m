function [x fval exitflag output population scores] = __ga_problem__ (problem)

  ## first instruction
  state.StartTime = time ();

  ## second instruction
  output = struct ("randstate", rand ("state"),
                   "randnstate", randn ("state"));

  ## instructions not to be executed at each generation
  state.Population(1:problem.options.PopulationSize, 1:problem.nvars) = ...
      __ga_initial_population__ (problem.nvars,
                                 problem.fitnessfcn,
                                 problem.options);
  state.Generation = 0;
  private_state = __ga_problem_private_state__ (problem.options);
  state.Selection = __ga_problem_state_selection__ (private_state,
                                                    problem.options);

  ## instructions to be executed at each generation
  state = __ga_problem_update_state_at_each_generation__ (state, problem,
                                                          private_state);

  NextPopulation = zeros (problem.options.PopulationSize, problem.nvars);
  
  bounds=[problem.lb; problem.ub];
  
  ##SW start
  flag='init';
  problem.options.OutputFcns(problem.options, state, flag);
  flag='iter';
  ##SW end

    while (! __ga_stop__ (problem, state)) ## fix a generation

    ##SW start
    problem.options.OutputFcns(problem.options, state, flag);
    ##SW end
  
  
    ## elite
    if (private_state.ReproductionCount.elite > 0)
      [trash IndexSortedScores] = sort (state.Score);
      NextPopulation(state.Selection.elite, 1:problem.nvars) = ...
          state.Population ...
          (IndexSortedScores(1:private_state.ReproductionCount.elite, 1),
           1:problem.nvars);
    endif

    ## selection for crossover and mutation
    parents(1, 1:private_state.nParents) = __ga_selectionfcn__ ...
        (state.Expectation, private_state.nParents, problem.options);

    ## crossover
    if (private_state.ReproductionCount.crossover > 0)
      NextPopulation(state.Selection.crossover, 1:problem.nvars) = ...
          __ga_crossoverfcn__ ...
          (parents(1, private_state.parentsSelection.crossover),
           problem.options, problem.nvars, problem.fitnessfcn,
           [problem.lb; problem.ub], 
           state.Population);
    endif

    ## mutation
    if (private_state.ReproductionCount.mutation > 0)
      NextPopulation(state.Selection.mutation, 1:problem.nvars) = ...
          __ga_mutationfcn__ ...
          (parents(1, private_state.parentsSelection.mutation),
           problem.options, problem.nvars, problem.fitnessfcn,
           state, state.Score,
           state.Population);
    endif

    ##SW start   
    if ~isempty(bounds)
      [m n]=size(NextPopulation);
      test_results = __ga_test_population__(NextPopulation, bounds);
      p1 = state.Population(parents(1, 1), :);
      p2 = state.Population(parents(1, 2), :);
      for i=1:m
        if(~test_results(i))
          alpha=rand();
          NextPopulation(i,:) = alpha*p1 + (1-alpha)*p2;
        end
      end
    end
    ##SW end
  
  ## update state structure
    state.Population(1:problem.options.PopulationSize,
                     1:problem.nvars) = NextPopulation;
    state.Generation++;
    state = __ga_problem_update_state_at_each_generation__ (state, problem,
                                                            private_state);
  endwhile

  ##SW start
  flag='done';
  problem.options.OutputFcns(problem.options, state, flag);
  ##SW end

  [x fval exitflag output population scores] = ...
      __ga_problem_return_variables__ (state, problem);
endfunction

                                #state structure fields
                                #DONE state.Population
                                #DONE state.Score
                                #DONE state.Generation
                                #DONE state.StartTime
                                #state.StopFlag
                                #DONE state.Selection
                                #DONE state.Expectation
                                #DONE state.Best
                                #state.LastImprovement
                                #state.LastImprovementTime
                                #state.NonlinIneq
                                #state.NonlinEq