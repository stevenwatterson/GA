function expectation = fitscalingrank (scores, nParents)
  nr_scores = rows (scores);
  r(1, 1:nr_scores) = ranks (scores(1:nr_scores, 1));
                                #TODO
                                #ranks ([7,2,2]) == [3.0,1.5,1.5]
                                #is [3,1,2] (or [3,2,1]) useful? 
  expectation_wo_nParents(1, 1:nr_scores) = arrayfun (@(n) 1 / sqrt (n), r);
  expectation(1, 1:nr_scores) = ...
      (nParents / sum (expectation_wo_nParents)) * ...
      expectation_wo_nParents;
endfunction


## number of input arguments
# TODO

## number of output arguments
# TODO

## type of arguments
# TODO

# TODO

%!shared scores, nParents, expectation
%! scores = rand (20, 1);
%! nParents = 32;
%! expectation = fitscalingrank (scores, nParents);
%!assert (sum (expectation), nParents, 1e-9);
%!test
%! [trash index_min_scores] = min (scores);
%! [trash index_max_expectation] = max (expectation);
%! assert (index_min_scores, index_max_expectation);
%!test
%! [trash index_max_scores] = max (scores);
%! [trash index_min_expectation] = min (expectation);
%! assert (index_max_scores, index_min_expectation);
