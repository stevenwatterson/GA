function stop = __ga_stop__ (problem, state)
  Generations = ...
      (state.Generation >= problem.options.Generations);

  TimeLimit = ...
      ((time () - state.StartTime) >= problem.options.TimeLimit);

  FitnessLimit = ...
      (state.Best(state.Generation + 1, 1) <= problem.options.FitnessLimit);

  stop = (Generations ||
          TimeLimit ||
          FitnessLimit);
endfunction