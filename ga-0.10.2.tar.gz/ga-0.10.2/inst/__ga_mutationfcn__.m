function mutationChildren = ...
      __ga_mutationfcn__ (parents, options, nvars, FitnessFcn,
                          state, thisScore,
                          thisPopulation)
  mutationChildren(1:(columns (parents)), 1:nvars) = ...
      options.MutationFcn{1, 1} (parents(1, :), options, nvars, FitnessFcn,
                                 state, thisScore,
                                 thisPopulation(:, 1:nvars));
endfunction