function test_results = __ga_test_population__(thisPopulation, bounds)
  [m n] = size(thisPopulation);
  test_results_inv_all = zeros(m,1);
  for i=1:n
    test_results_inv_all = test_results_inv_all + (thisPopulation(:,i)<bounds(1,i)) + (thisPopulation(:,i)>bounds(2,i));
  end
  test_results_inv = (test_results_inv_all>0);
  test_results = ones(m,1)-test_results_inv;     
endfunction
