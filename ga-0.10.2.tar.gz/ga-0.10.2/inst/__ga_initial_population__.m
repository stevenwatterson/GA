function Population = ...
      __ga_initial_population__ (GenomeLength, FitnessFcn, options)
  if (isempty (options.InitialPopulation))
    Population(1:options.PopulationSize, 1:GenomeLength) = ...
        options.CreationFcn (GenomeLength, FitnessFcn, options);
  else
    if (columns (options.InitialPopulation) != GenomeLength) ## columns (InitialPopulation) > 0
      error ("nonempty 'InitialPopulation' must have 'GenomeLength' columns");
    else ## rows (InitialPopulation) > 0
      nrIP = rows (options.InitialPopulation);
      if (nrIP > options.PopulationSize)
        error ("nonempty 'InitialPopulation' must have no more than \
            'PopulationSize' rows");
      elseif (nrIP == options.PopulationSize)
        Population(1:options.PopulationSize, 1:GenomeLength) = ...
            options.InitialPopulation;
      else # rows (InitialPopulation) < PopulationSize

        ## create a complete new population, and then select only needed
        ## individuals (creating only a partial population is difficult)
        CreatedPopulation(1:options.PopulationSize, 1:GenomeLength) = ...
            options.CreationFcn (GenomeLength, FitnessFcn, options);
        Population(1:options.PopulationSize, 1:GenomeLength) = vertcat ...
            (options.InitialPopulation(1:nrIP, 1:GenomeLength),
             CreatedPopulation(1:(options.PopulationSize - nrIP),
                               1:GenomeLength));
      endif
    endif
  endif
endfunction

