function Population = gacreationuniform (GenomeLength, FitnessFcn, options)
  [LB(1, 1:GenomeLength) UB(1, 1:GenomeLength)] = ...
      __ga_popinitrange__ (options.PopInitRange, GenomeLength);

  ## pseudocode
  ##
  ## Population = Delta * RandomPopulationBetween0And1 + Offset
  Population(1:options.PopulationSize, 1:GenomeLength) = ...
      ((ones (options.PopulationSize, 1) * (UB - LB)) .* ...
       rand (options.PopulationSize, GenomeLength)) + ...
      (ones (options.PopulationSize, 1) * LB);
endfunction


## number of input arguments
# TODO

## number of output arguments
# TODO

## type of arguments
# TODO

# TODO
