function state = ...
      __ga_problem_update_state_at_each_generation__ (state, problem,
                                                      private_state)
  if ((state.Generation > 0) || isempty (problem.options.InitialScores))
    state.Score(1:problem.options.PopulationSize, 1) = ...
        __ga_scores__ (problem, state.Population);
  else ## (Generation == 0) && (! isempty (InitialScores))
    nrIS = rows (problem.options.InitialScores);
    #assert (rows (problem.options.InitialPopulation) <= problem.options.PopulationSize); ## DEBUG
    if (nrIS <= rows (problem.options.InitialPopulation))
      missing_rows = (nrIS+1):problem.options.PopulationSize;
      state.Score(1:problem.options.PopulationSize, 1) = ...
          [problem.options.InitialScores(:, 1);
           (__ga_scores__ (problem, state.Population(missing_rows, :)))
           ];
    else
      error ("rows (InitialScores) > rows (InitialPopulation)");
    endif
  endif
  state.Expectation(1, 1:problem.options.PopulationSize) = ...
      problem.options.FitnessScalingFcn (state.Score, private_state.nParents);
  state.Best(state.Generation + 1, 1) = min (state.Score);
endfunction


%!error
%! state.Generation = 0;
%! problem = struct ("fitnessfcn", @rastriginsfcn, "nvars", 2, "options", gaoptimset ("Generations", 10, "InitialScores", [0; 0; 0]));
%! unused = 0;
%! __ga_problem_update_state_at_each_generation__ (state, problem, unused);