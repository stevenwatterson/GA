function xoverKids = __ga_crossoverfcn__ (parents, options, nvars, FitnessFcn,
                                          bounds,
                                          thisPopulation)

  ## preconditions
  nc_parents = columns (parents);
  if (rem (nc_parents, 2) != 0)
    error ("'parents' must have an even number of columns");
  endif

  xoverKids(1:(nc_parents / 2), 1:nvars) = options.CrossoverFcn ...
      (parents(1, 1:nc_parents), options, nvars, FitnessFcn,
       bounds,
       thisPopulation(:, 1:nvars));
endfunction