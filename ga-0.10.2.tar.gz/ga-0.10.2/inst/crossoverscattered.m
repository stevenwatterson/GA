function xoverKids = crossoverscattered (parents, options, nvars, FitnessFcn,
                                         bounds,
                                         thisPopulation)

  ## simplified example (nvars == 4)
  ## p1 = [varA varB varC varD]
  ## p2 = [var1 var2 var3 var4]
  ## b = [1 1 0 1]
  ## child = [varA varB var3 varD]
  nc_parents = columns (parents);
  n_children = nc_parents / 2;
  p1(1:n_children, 1:nvars) = ...
      thisPopulation(parents(1, 1:n_children), 1:nvars);
  p2(1:n_children, 1:nvars) = ...
      thisPopulation(parents(1, n_children + (1:n_children)), 1:nvars);
  ##Start SW Edit----
  ##Start old code----
  %b(1:n_children, 1:nvars) = randi (1, n_children, nvars); ## TODO: test randi
  ##End old code----
  ##Start new code----
  b(1:n_children, 1:nvars) = randi ([0 1], n_children, nvars); ## TODO: test randi
  ##End new code----
  ##End SW Edit----
  xoverKids(1:n_children, 1:nvars) = ...
      b .* p1 + (ones (n_children, nvars) - b) .* p2;
      
  
  
endfunction


