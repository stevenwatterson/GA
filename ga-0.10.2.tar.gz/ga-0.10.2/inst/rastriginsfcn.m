function retval = rastriginsfcn (x)
  if ((nargout != 1) ||
      (nargin != 1) || (columns (x) != 2))
    print_usage ();
  else
    x1 = x(:, 1);
    x2 = x(:, 2);
    retval = 20 + (x1 .** 2) + (x2 .** 2) - 10 .* (cos (2 .* pi .* x1) +
                                                   cos (2 .* pi .* x2));
  endif
endfunction


## number of input arguments
%!error y = rastriginsfcn ()
%!error y = rastriginsfcn ([0, 0], "other argument")

## number of output arguments
%!error [y1, y2] = rastriginsfcn ([0, 0])

## type of arguments
%!error y = rastriginsfcn ([0; 0])
%!error y = rastriginsfcn (zeros (2, 3)) # TODO: document size of x

%!assert (rastriginsfcn ([0, 0]), 0)
%!assert (rastriginsfcn ([0, 0; 0, 0]), [0; 0])
%!assert (rastriginsfcn (zeros (3, 2)), [0; 0; 0])
