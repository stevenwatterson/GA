## -*- texinfo -*-
## @deftypefn{Function File} {@var{options} =} gaoptimset
## @deftypefnx{Function File} {@var{options} =} gaoptimset ('@var{param1}', @var{value1}, '@var{param2}', @var{value2}, @dots{})
## Create genetic algorithm options structure.
##
## @strong{Inputs}
## @table @var
## @item param
## Parameter to set. Unspecified parameters are set to their default
## values; specifying no parameters is allowed.
## @item value
## Value of @var{param}.
## @end table
##
## @strong{Outputs}
## @table @var
## @item options
## Structure containing the options, or parameters, for the genetic algorithm.
## @end table
##
## @strong{Options}
## @table @code
## @item CreationFcn
##       Default function is @@gacreationuniform
## @item CrossoverFcn
##       Default function is @@crossoverscattered
## @item CrossoverFraction
##       Default value is 0.0
## @item EliteCount
##       Default value is 2
## @item FitnessLimit
## @item FitnessScalingFcn
##       Default function is @@fitscalingrank
## @item Generations
##       Default valie is 100
## @item InitialPopulation
##       Can be partial.
## @item InitialScores
##       column vector | [] (default) . Can be partial.
## @item MutationFcn
##       Default mutation is @{ @@mutationgaussian, scale, shrink @}
##
## scale and shrink are 1.0
## @item PopInitRange
## @item PopulationSize
## @item SelectionFcn
##       Default function is @@selectionstochunif
## @item TimeLimit
## @item UseParallel
##       "always" | "never" (default) . Parallel evaluation of objective function. TODO: parallel evaluation of nonlinear constraints
## @item Vectorized
##       "on" | "off" (default) . Vectorized evaluation of objective function. TODO: vectorized evaluation of nonlinear constraints
## @end table
##
## @seealso{ga}
## @end deftypefn

## Author: Luca Favatella <slackydeb@gmail.com>
## Version: 4.4.8

function options = gaoptimset (varargin)
  if ((nargout != 1) ||
      (mod (length (varargin), 2) == 1))
    print_usage ();
  else

    ## initialize the return variable to a structure with all parameters
    ## set to their default value
    options = __gaoptimset_default_options__ ();

    ## set custom options
    for i = 1:2:length (varargin)
      param = varargin{i};
      value = varargin{i + 1};
      if (! isfield (options, param))
        error ("wrong parameter");
      else
        options = setfield (options, param, value);
      endif
    endfor
  endif
endfunction

