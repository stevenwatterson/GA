function [x fval exitflag output population scores] = ...
      __ga_problem_return_variables__ (state, problem)
  [trash IndexMinScore] = min (state.Score);
  x = state.Population(IndexMinScore, 1:problem.nvars);

  fval = problem.fitnessfcn (x);

  #TODO exitflag
  exitflag = [];

  ## output.randstate and output.randnstate must be assigned at the
  ## start of the algorithm
  output.generations = state.Generation;
                                #TODO output.funccount
                                #TODO output.message
                                #TODO output.maxconstraint

  population = state.Population;

  scores = state.Score;
endfunction
