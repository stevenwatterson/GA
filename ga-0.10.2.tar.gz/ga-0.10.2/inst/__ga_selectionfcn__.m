function parents = __ga_selectionfcn__ (expectation, nParents, options)
  parents(1, 1:nParents) = ...
      options.SelectionFcn (expectation(1, :), nParents, options);
endfunction