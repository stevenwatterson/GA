function [LB UB] = __ga_popinitrange__ (PopInitRange, nvars)
  switch (columns (PopInitRange))
    case 1
      tmpPIR(1:2, 1:nvars) = PopInitRange(1:2, 1) * ones (1, nvars);
    case nvars
      tmpPIR(1:2, 1:nvars) = PopInitRange(1:2, 1:nvars);
  endswitch
  LB(1, 1:nvars) = tmpPIR(1, 1:nvars);
  UB(1, 1:nvars) = tmpPIR(2, 1:nvars);
endfunction